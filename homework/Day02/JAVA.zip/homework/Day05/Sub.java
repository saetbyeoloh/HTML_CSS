package Day05;

public class Sub extends Calc {
	@Override
	public int calculate() {
		return a - b;
	}
}
