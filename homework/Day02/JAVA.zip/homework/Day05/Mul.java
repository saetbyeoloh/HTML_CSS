package Day05;

public class Mul extends Calc {
	@Override
	public int calculate() {
		return a * b;
	}
}
