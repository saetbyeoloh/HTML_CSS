package Day03;

public class _09_basic02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cat cat = new Cat();
		System.out.println("------------------------------");
		
		cat.calve();
		cat.howling();
		System.out.println("------------------------------");
		
		Lion lion = new Lion();
		System.out.println("------------------------------");
		
		lion.calve();
		lion.howling();
		lion.hunt();
	}

}
