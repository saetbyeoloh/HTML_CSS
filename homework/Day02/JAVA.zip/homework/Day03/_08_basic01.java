package Day03;

public class _08_basic01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PhoneInfo phoneInfo = new PhoneInfo("ȫ�浿", "010-0000-0000", "0000�� 00�� 00��");
		
		phoneInfo.showPhoneInfo();
	}

}
