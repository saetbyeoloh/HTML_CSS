package Day06;

public interface ICar {
	void startEngine();
	void speedUp();
	void speedDown();
	void hitBreak();
}
