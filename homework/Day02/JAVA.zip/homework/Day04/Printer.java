package Day04;

public class Printer {
	String model;
	String company;
	String connectType;
	int paper;
	
	public void print() {
		
	}
}
