package Day04;

public class Cat extends Animal{
	Cat() {
		this.kind = "������";
	}
	
	@Override
	public void sound() {
		System.out.println("�Ŀ�");
	}
}
