package Day04;

public class _04_super {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SportsCar sc1 = new SportsCar();
		sc1.driveMode = 1;
		sc1.drive();
		System.out.println("---------------------");
		
		SportsCar sc2 = new SportsCar();
		sc2.driveMode = 2;
		sc2.drive();
	}

}
