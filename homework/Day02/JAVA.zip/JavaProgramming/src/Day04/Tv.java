package Day04;

public class Tv {
	protected String company;
	
	protected void showCompany() {
		System.out.println("������� : " + company);
	}
}
