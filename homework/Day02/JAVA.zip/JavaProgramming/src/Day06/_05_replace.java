package Day06;

public class _05_replace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "hello java";
		String str2 = str1.replace("java", "python");
		
		System.out.println(str2);
	}

}
