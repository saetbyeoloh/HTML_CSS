package Day06;

public class _12_abs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1 = -5;
		double num2 = -3.14;
		
		System.out.println(Math.abs(num1));
		System.out.println(Math.abs(num2));
	}

}
