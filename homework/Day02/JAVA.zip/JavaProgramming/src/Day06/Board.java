package Day06;

public class Board {
	public String title;
	public String content;
	public String writer;
	
	public Board(String title, String content, String writer) {
		this.title = title;
		this.content = content;
		this.writer = writer;
	}
}
