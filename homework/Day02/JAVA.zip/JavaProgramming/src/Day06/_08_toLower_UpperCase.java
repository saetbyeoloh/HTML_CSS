package Day06;

public class _08_toLower_UpperCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "bit";
		String str2 = "HELLO JAVA";
		
		//���ĺ� �빮�ڷ� ġȯ
		System.out.println(str1.toUpperCase());
		//���ĺ� �ҹ��ڷ� ġȯ
		System.out.println(str2.toLowerCase());
	}

}
