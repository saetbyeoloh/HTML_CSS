package Day06;

public class _02_charAt_length {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "hello java!!";
		
		for(int i = 0; i < str.length(); i++) {
			System.out.println(str.charAt(i));
		}
	}

}
