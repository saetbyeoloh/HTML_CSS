package Day06;

public class _10_valueOf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int�� 10�� String�� "10" ġȯ
		String str1 = String.valueOf(10);
		//char�� 'c'�� String�� "c" ġȯ
		String str2 = String.valueOf('c');
		//double�� 3.14�� String�� "3.14" ġȯ
		String str3 = String.valueOf(3.14);
		//boolean�� false�� String�� "false" ġȯ
		String str4 = String.valueOf(false);
		
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
		System.out.println(str4);
	}

}
