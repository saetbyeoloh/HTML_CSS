package Day06;

public class _09_trim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "   hello java   ";
		String str2 = str1.trim();
		
		System.out.println(str1);
		System.out.println(str2);
	}

}
