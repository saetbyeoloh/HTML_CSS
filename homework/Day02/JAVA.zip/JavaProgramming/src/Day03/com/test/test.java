package Day03.com.test;

public class test {
	public static int num = 10;
}
